# Roadmap Patch — Stage 27

## Status correction
The repository already contains commit `44b49dbe` implementing Stage 26. Update the official roadmap so Stage 26 is marked **COMPLETED**, after validation/CI confirms the implementation.

# Stage 27 — Network Device Monitoring & Governed WAN Actions 🟡 PLANNED

## Objective
Bring MikroTik RouterOS and pfSense into the same operational model already used by InfraOps AI for compute infrastructure: inventory + telemetry + health + AI + governed Actions + audit.

The first business goal is simple and high-value for small/medium networks:

> Monitor WAN health and allow the AI, under policy, to change the preferred/default Internet link safely.

## Initial official drivers
1. MikroTik RouterOS
2. pfSense

## Stage 27A — Driver Framework
- normalized `NetworkDeviceDriver`;
- capability discovery;
- credentials via Secrets;
- health/telemetry contract;
- action contract;
- driver version compatibility;
- explicit unsupported capability handling.

## Stage 27B — MikroTik Monitoring
- identity/model/serial/version;
- CPU/RAM/uptime/storage/temperature when available;
- interfaces;
- WAN state;
- throughput;
- gateway reachability;
- latency/loss;
- route/default-route inventory;
- VPN status where safely supported.

## Stage 27C — pfSense Monitoring
- identity/version;
- CPU/RAM/uptime;
- interfaces;
- WAN/gateway state;
- latency/loss;
- gateway groups;
- tier/weight configuration;
- VPN/service health where safely supported.

## Stage 27D — Governed WAN Actions
Normalized Actions:
- `network.set_primary_wan`
- `network.set_wan_failover`
- `network.set_wan_balance`
- `network.enable_wan`
- `network.disable_wan`

Vendor drivers translate normalized intent into vendor-specific operations.

## Stage 27E — Safe Change Workflow
Every mutating WAN Action:
`Intent → Capability Check → Policy → Approval/Autonomy → Precheck → Snapshot → Execute → Postcheck → Rollback if needed → Audit`.

## Stage 27F — AI Experience
Examples:
- “Torne a Claro o link principal do MikroTik da Loja Centro.”
- “Troque o link padrão do pfSense para a Vivo.”
- “Deixe Vivo como Tier 1 e Claro como Tier 2.”
- “Balanceie novas conexões aproximadamente 70/30.”
- “Por que o link da filial está ruim?”

The AI never generates arbitrary RouterOS/pfSense shell/config commands for execution.

## Stage 27G — Autonomous WAN Failover
Use Stage 22/23 primitives:
- loss/latency trigger;
- minimum unhealthy duration;
- debounce;
- cooldown;
- hysteresis;
- recovery window;
- circuit breaker;
- automatic rollback;
- optional return-to-primary policy.

## Gate
Stage 27 is complete only when:
- both drivers are tenant-isolated;
- secrets never leak;
- WAN switch has deterministic pre/postcheck;
- rollback is tested;
- AI cannot bypass Action Registry/Policy Engine;
- loss/latency failover resists flapping;
- audit contains before/after state;
- degraded/unreachable device produces safe failure;
- no arbitrary command execution is required.
