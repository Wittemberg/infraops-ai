# Roadmap Patch — Stage 28

## Stage 28 — Simple Experience, Guided Operations & Frontend Refactor 🟡 PLANNED

### Objective
Reorganize the InfraOps AI experience around the day-to-day work of small IT providers, MEIs and small MSPs.

The platform is already technically broad. Stage 28 does **not** add another deep infrastructure subsystem. It makes existing capabilities easier to understand, configure, operate and demonstrate to customers.

### Product principle
> **Technical depth underneath. Operational simplicity on top.**

### Primary outcomes
- simpler navigation;
- customer-centered workflow;
- Portuguese-first terminology;
- Simple Mode / Technical Mode;
- Daily Operations Center;
- Customer Summary;
- guided onboarding;
- recommended defaults;
- human-readable statuses and approvals;
- AI as a primary entry point;
- reports as a first-class product area;
- refactoring of oversized frontend components;
- removal of demo/default operational data from production UI state;
- stronger separation between UI, state, fixtures and API services.

### Stage 28 releases
- 28A — Information Architecture & Language
- 28B — Frontend Foundation Refactor
- 28C — Home / Daily Operations Center
- 28D — Customer-Centered Experience
- 28E — Simple Mode / Technical Mode
- 28F — Guided Onboarding
- 28G — Humanized Alerts, Approvals & Actions
- 28H — AI Assistant as Primary Entry Point
- 28I — Reports & Customer Value
- 28J — Accessibility, Responsiveness & Usability Validation

### Completion gate
Stage 28 is complete only when:
- a non-specialist user can add a customer and reach useful monitoring without reading technical documentation;
- all primary navigation labels are understandable in Portuguese;
- technical terms are moved to details/tooltips/Technical Mode where possible;
- existing RBAC, tenant isolation, actions, policies and audit behavior are preserved;
- Simple Mode does not reduce security or hide critical operational consequences;
- existing production features remain reachable;
- no demo tenant/node/workload is silently injected into production state;
- frontend code is split by feature/domain and passes lint/build/tests;
- usability scenarios defined in the implementation guide pass.
