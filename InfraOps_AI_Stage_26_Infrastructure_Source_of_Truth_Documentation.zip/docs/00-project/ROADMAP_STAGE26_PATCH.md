# Roadmap Patch — Etapa 26

## Etapa 26 — Infrastructure Source of Truth & Physical Topology 🟡 PLANEJADA

### Público prioritário
Pequenos e médios prestadores de TI, MEIs, MSPs e departamentos de TI que administram múltiplos clientes e precisam substituir planilhas, anotações dispersas e conhecimento informal por uma fonte confiável e simples.

### Objetivo
Dar ao tenant controle documental e operacional de sua infraestrutura física e lógica sem dependência obrigatória de software externo.

### Releases
- **26A — Customer Infrastructure Book:** Sites, Locations, Assets, patrimônio, documentos, contatos, garantias, QR Code e histórico.
- **26B — Rack & Connectivity:** Racks, interfaces, switch ports, conexões e topologia simples.
- **26C — Network Source of Truth:** VLANs, subnets, IPAM básico e circuitos WAN.
- **26D — Discovery:** descoberta segura, SNMP, LLDP e reconciliação.
- **26E — Operational Tools:** Health Score, checklist de visita, relatórios, manutenção, garantia/EOL.
- **26F — AI & Advisor Integration:** consultas naturais, contexto físico, SPOF e recomendações.

### Princípio
> Se faz parte da infraestrutura do tenant, o InfraOps AI deve saber o que é, onde está, a que está conectado e do que depende — sem inventar informação e sem depender de plataforma externa.

### Fora do escopo inicial
DCIM 3D, planta baixa, heatmap Wi-Fi, BGP/OSPF avançado, NetFlow, configuração automática de switches, gestão profunda de patch panels/cabos e dependência obrigatória de CMDB/IPAM externo.
