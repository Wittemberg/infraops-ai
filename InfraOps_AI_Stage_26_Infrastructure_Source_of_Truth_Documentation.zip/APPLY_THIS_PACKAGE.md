# Aplicação — Stage 26 Documentation Package

Este pacote foi preparado para ser copiado sobre a raiz do repositório `infraops-ai`.

## Importante
`ROADMAP_STAGE26_PATCH.md` e `MARKETING_CONCEPTS_STAGE26_PATCH.md` são patches deliberados para evitar sobrescrever documentos que podem ter evoluído entre a geração do pacote e o commit. A equipe/IA implementadora deve incorporar o conteúdo nos arquivos oficiais e então remover os patches.

## Novos documentos
- docs/06-product/STAGE_26_INFRASTRUCTURE_SOURCE_OF_TRUTH.md
- docs/02-implementation/26_INFRASTRUCTURE_SOURCE_OF_TRUTH_IMPLEMENTATION.md
- docs/01-architecture/adr/ADR-018-native-infrastructure-source-of-truth.md
- docs/01-architecture/adr/ADR-019-inventory-trust-and-reconciliation.md
- docs/08-marketing/STAGE_26_MARKETING_IMPACT.md
- docs/08-marketing/campaigns/STAGE_26_CAMPAIGN_CONCEPTS.md
- docs/08-marketing/sales/STAGE_26_SALES_PITCH.md

## Patches
- docs/00-project/ROADMAP_STAGE26_PATCH.md
- docs/08-marketing/MARKETING_CONCEPTS_STAGE26_PATCH.md

## Commit sugerido
```bash
git add docs/
git commit -m "docs: plan stage 26 infrastructure source of truth"
git push
```
